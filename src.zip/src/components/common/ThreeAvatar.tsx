import React, { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { Environment, Html, useGLTF } from "@react-three/drei";
import type { Mesh, Object3D, Group } from "three";

export type Gender = "male" | "female";
export type PollyViseme =
  | "sil" | "p" | "t" | "S" | "T" | "f" | "k" | "i" | "u" | "r" | "a" | "e" | "o";

export interface VisemeFrame { time: number; value: PollyViseme }

export interface ThreeAvatarProps {
  gender: Gender;
  modelUrl: string;
  speaking?: boolean;
  visemes?: VisemeFrame[];
  audioSrc?: string;
  autoPlayAudio?: boolean;
  mood?: "neutral" | "happy" | "sad";
  className?: string;
  scale?: number;
  onEnded?: () => void;
  morphMap?: Partial<Record<PollyViseme, { key: string; w?: number }[]>>;
  targetMeshName?: string;
  morphNames?: Partial<{
    jawOpen: string; blinkL: string; blinkR: string; smileL: string; smileR: string;
  }>;
  nodeNames?: Partial<{ head: string; eyeL: string; eyeR: string }>;
}

const DEFAULT_VISEME_MAP: NonNullable<ThreeAvatarProps["morphMap"]> = {
  sil: [{ key: "jawOpen", w: 0 }],
  p:   [{ key: "viseme_PBM", w: 1 }],
  t:   [{ key: "viseme_DNT", w: 0.8 }],
  S:   [{ key: "viseme_SH",  w: 1 }],
  T:   [{ key: "viseme_TH",  w: 1 }],
  f:   [{ key: "viseme_FV",  w: 1 }],
  k:   [{ key: "viseme_K",   w: 1 }],
  i:   [{ key: "viseme_IY",  w: 1 }, { key: "jawOpen", w: 0.2 }],
  u:   [{ key: "viseme_UW",  w: 1 }],
  r:   [{ key: "viseme_R",   w: 1 }],
  a:   [{ key: "viseme_AA",  w: 1 }, { key: "jawOpen", w: 0.55 }],
  e:   [{ key: "viseme_EH",  w: 1 }, { key: "jawOpen", w: 0.35 }],
  o:   [{ key: "viseme_AO",  w: 1 }, { key: "jawOpen", w: 0.45 }],
};

function clamp01(x: number) { return Math.max(0, Math.min(1, x)); }
function lerp(a: number, b: number, t: number) { return a + (b - a) * t; }

function currentVisemeFor(tMs: number, frames: VisemeFrame[]): PollyViseme {
  if (!frames?.length) return "sil";
  let i = 0;
  while (i + 1 < frames.length && frames[i + 1].time <= tMs) i++;
  return frames[i]?.value ?? "sil";
}

function useRandomStepper(periodMin = 1.2, periodMax = 2.2) {
  const [value, setValue] = useState<number>(0);
  const nextAtRef = useRef<number>(0);
  useFrame(({ clock }) => {
    const t = clock.getElapsedTime();
    if (t >= nextAtRef.current) {
      setValue(Math.random() * 2 - 1);
      nextAtRef.current = t + (periodMin + Math.random() * (periodMax - periodMin));
    }
  });
  return value;
}

type GLTFResult = { scene: Group; nodes?: Record<string, Object3D> };

function isMeshWithMorphs(obj: Object3D): obj is Mesh & { morphTargetDictionary: Record<string, number>; morphTargetInfluences: number[] } {
  const m = obj as Mesh & { morphTargetDictionary?: Record<string, number>; morphTargetInfluences?: number[] } & { isMesh?: boolean };
  return Boolean((m as unknown as { isMesh?: boolean }).isMesh && m.morphTargetDictionary && m.morphTargetInfluences);
}

function HeadScene({
  modelUrl,
  speaking = false,
  visemes = [],
  audioRef,
  morphMap = DEFAULT_VISEME_MAP,
  morphNames = { jawOpen: "jawOpen", blinkL: "blink_L", blinkR: "blink_R", smileL: "smile_L", smileR: "smile_R" },
  nodeNames = { head: "Head", eyeL: "eye_L", eyeR: "eye_R" },
  mood = "neutral",
  scale = 1,
  onEnded,
  targetMeshName,
}: Omit<ThreeAvatarProps, "className" | "audioSrc" | "autoPlayAudio" | "gender"> & { audioRef: React.RefObject<HTMLAudioElement | null> }) {
  const gltf = useGLTF(modelUrl) as unknown as GLTFResult;
  const scene = gltf.scene;
  const nodes = useMemo(() => (gltf.nodes ?? {}) as Record<string, Object3D>, [gltf]);

  const morphMesh = useMemo<Mesh | undefined>(() => {
    if (targetMeshName && nodes[targetMeshName]) return nodes[targetMeshName] as Mesh;
    let found: Mesh | undefined;
    scene.traverse((obj: Object3D) => {
      if (!found && isMeshWithMorphs(obj)) found = obj as Mesh;
    });
    return found;
  }, [scene, nodes, targetMeshName]);

  const blinkRef = useRef<{ phase: number; target: number; nextAt: number; holdUntil: number }>({ phase: 0, target: 0, nextAt: 0, holdUntil: 0 });
  const [startMs] = useState<number>(() => performance.now());

  const eyeNudge = useRandomStepper(1, 1.8);
  const headNudge = useRandomStepper(1.5, 2.6);

  useFrame((state, delta) => {
    if (!morphMesh) return;
    const t = state.clock.getElapsedTime();
    if (t >= blinkRef.current.nextAt && blinkRef.current.target === 0) {
      blinkRef.current.target = 1;
      blinkRef.current.holdUntil = t + 0.12;
    } else if (blinkRef.current.target === 1 && t >= blinkRef.current.holdUntil) {
      blinkRef.current.target = 0;
      blinkRef.current.nextAt = t + (2.5 + Math.random() * 2);
    }
    blinkRef.current.phase = lerp(blinkRef.current.phase, blinkRef.current.target, 1 - Math.pow(0.001, delta * 20));

    let tMs = performance.now() - startMs;
    const a = audioRef.current;
    if (a && !a.paused) tMs = a.currentTime * 1000;
    const current = speaking ? currentVisemeFor(tMs, visemes) : "sil";

    const dict = (morphMesh as Mesh & { morphTargetDictionary?: Record<string, number> }).morphTargetDictionary;
    const infl = (morphMesh as Mesh & { morphTargetInfluences?: number[] }).morphTargetInfluences;
    if (dict && infl) {
      for (let i = 0; i < infl.length; i++) infl[i] = lerp(infl[i], 0, clamp01(1 - Math.pow(0.001, delta)));
      const targets = (morphMap?.[current] ?? []) as { key: string; w?: number }[];
      for (const { key, w = 1 } of targets) {
        const idx = dict[key];
        if (idx !== undefined) infl[idx] = lerp(infl[idx], clamp01(w), 1 - Math.pow(0.001, delta * 12));
      }
      if (mood === "happy") {
        const l = dict[morphNames.smileL ?? "smile_L"];
        const r = dict[morphNames.smileR ?? "smile_R"];
        if (l !== undefined) infl[l] = lerp(infl[l], 0.18, 1 - Math.pow(0.001, delta * 2));
        if (r !== undefined) infl[r] = lerp(infl[r], 0.18, 1 - Math.pow(0.001, delta * 2));
      }
      const bl = dict[morphNames.blinkL ?? "blink_L"];
      const br = dict[morphNames.blinkR ?? "blink_R"];
      if (bl !== undefined) infl[bl] = lerp(infl[bl], blinkRef.current.phase, 1 - Math.pow(0.001, delta * 20));
      if (br !== undefined) infl[br] = lerp(infl[br], blinkRef.current.phase, 1 - Math.pow(0.001, delta * 20));
      const jaw = dict[morphNames.jawOpen ?? "jawOpen"];
      if (jaw !== undefined && speaking) infl[jaw] = clamp01(infl[jaw] + 0.03 * Math.sin((tMs / 1000) * 8));
    }

    const headNode = nodes[nodeNames.head ?? "Head"] as Object3D | undefined;
    const eyeL = nodes[nodeNames.eyeL ?? "eye_L"] as Object3D | undefined;
    const eyeR = nodes[nodeNames.eyeR ?? "eye_R"] as Object3D | undefined;

    if (headNode) {
      const amt = 0.02;
      headNode.rotation.y = amt * headNudge;
      headNode.rotation.x = amt * 0.6 * Math.sin((tMs / 1000) * 0.7);
    }
    if (eyeL && eyeR) {
      const eAmt = 0.05;
      eyeL.rotation.y = eAmt * eyeNudge;
      eyeR.rotation.y = eAmt * eyeNudge;
    }

    if (speaking && (!a || a.paused)) {
      const last = visemes[visemes.length - 1]?.time ?? 0;
      if (tMs > last + 120) onEnded?.();
    }
  });

  return (
    <group dispose={null} scale={scale}>
      <primitive object={scene} />
      <Environment preset="studio" />
    </group>
  );
}

export default function ThreeAvatar({
  gender,
  modelUrl,
  speaking = false,
  visemes = [],
  audioSrc,
  autoPlayAudio,
  mood = "neutral",
  className = "",
  scale = 1,
  onEnded,
  morphMap = DEFAULT_VISEME_MAP,
  targetMeshName,
  morphNames,
  nodeNames,
}: ThreeAvatarProps) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [webglOk, setWebglOk] = useState<boolean>(true);

  useEffect(() => {
    try {
      const canvas = document.createElement("canvas");
      const gl = canvas.getContext("webgl2") || canvas.getContext("webgl");
      if (!gl) setWebglOk(false);
    } catch {
      setWebglOk(false);
    }
  }, []);

  useEffect(() => {
    const a = audioRef.current;
    if (!a || !audioSrc) return;
    if (speaking && autoPlayAudio) {
      a.currentTime = 0;
      a.play().catch(() => {});
    } else if (!speaking) {
      a.pause();
      a.currentTime = 0;
    }
  }, [speaking, autoPlayAudio, audioSrc]);

  const hasModel = Boolean(modelUrl);

  return (
    <div className={"relative w-full aspect-square max-w-sm " + (className ?? "") }>
      {!webglOk || !hasModel ? (
        <div className="grid place-items-center w-full h-full rounded-2xl border border-neutral-800 bg-neutral-950 text-neutral-300 p-4 text-center">
          <div>
            <div className="text-base font-semibold mb-1">3D not supported</div>
            <div className="text-sm opacity-80">Falling back to 2D avatar… (enable WebGL)</div>
          </div>
        </div>
      ) : (
        <Canvas dpr={[1, 2]} camera={{ fov: 25, position: [0, 0, 3.1] }}>
          <ambientLight intensity={0.3} />
          <directionalLight intensity={0.8} position={[2, 3, 4]} />
          <React.Suspense fallback={<Html center>Loading head…</Html>}>
            <HeadScene
              modelUrl={modelUrl}
              speaking={speaking}
              visemes={visemes}
              audioRef={audioRef}
              morphMap={morphMap}
              morphNames={morphNames}
              nodeNames={nodeNames}
              mood={mood}
              scale={scale}
              onEnded={onEnded}
              targetMeshName={targetMeshName}
            />
          </React.Suspense>
        </Canvas>
      )}
      {audioSrc && (
        <audio ref={audioRef} src={audioSrc} onEnded={onEnded ?? undefined} className="hidden" />
      )}
      <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 text-[11px] px-2 py-0.5 rounded-full border border-neutral-800 bg-neutral-950 text-neutral-300">
        {speaking ? "Speaking…" : `Avatar (${gender})`}
      </div>
    </div>
  );
}
